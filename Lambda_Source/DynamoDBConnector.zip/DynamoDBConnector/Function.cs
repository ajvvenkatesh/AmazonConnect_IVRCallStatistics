using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon.Lambda.Core;
using Amazon.Runtime;
using Newtonsoft.Json;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace DynamoDBConnector
{
    public class Function
    {

        /// <summary>
        /// A simple function that takes a string and does a ToUpper
        /// </summary>
        /// <param name="input"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        /// 
        
        public string FunctionHandler(string input, ILambdaContext context)
        {
            return input?.ToUpper();
        }

        public object AddCustomerContactFlowJourneyData(ContactFlowData input, ILambdaContext context)
        {
            string jsonMessage = JsonConvert.SerializeObject(input);

            Console.WriteLine("AddCustomerContactFlowJourneyData : input : " + jsonMessage);

            DBConnector.GetInstance().AddCustomerMeta(input).Wait();
            
                string returnValue = "Success";
                var result = new
                {
                    RetVal = $"\"{returnValue}\""
                };

            Console.WriteLine("AddCustomerContactFlowJourneyData successfully executed..");
            return result;
        }        
    }
}
