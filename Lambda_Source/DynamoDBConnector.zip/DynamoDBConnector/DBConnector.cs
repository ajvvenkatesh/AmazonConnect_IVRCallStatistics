﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Amazon;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon.Runtime;

namespace DynamoDBConnector
{
    class DBConnector
    {
        private static DBConnector _instance = null;
        public static DBConnector GetInstance()
        {
            try
            {
                if (_instance == null)
                {
                    _instance = new DBConnector();
                }

                return _instance;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in DBConnector, GetInstance", ex);
            }

            return null;
        }

        public async Task AddCustomerMeta(ContactFlowData inputMessageData)
        {
            try
            {
                string region, iamUserID, iamSecretValue, tableName;

                Console.WriteLine("AddCustomerMeta : inputMessageData.contactID " + inputMessageData.Details.ContactData.ContactId + ", inputMessageData.customerNumber " + inputMessageData.Details.ContactData.CustomerEndpoint.Address +
                    ", inputMessageData.flowType " + inputMessageData.Details.Parameters.flowType + ", inputMessageData.initialContactID " + inputMessageData.Details.ContactData.InitialContactId +
                    ", inputMessageData.channel " + inputMessageData.Details.ContactData.Channel + ", inputMessageData.intent " + inputMessageData.Details.Parameters.Intent);

                string interactionDateTime = DateTime.Now.ToString("yyyyMMddHHmmss");

                tableName = Environment.GetEnvironmentVariable("DBTableName");
                region = Environment.GetEnvironmentVariable("Region");
                iamUserID = Environment.GetEnvironmentVariable("IAMUserID");
                iamSecretValue = Environment.GetEnvironmentVariable("IAMSecret");

                var awsCredentials = new BasicAWSCredentials(iamUserID, iamSecretValue);
                AmazonDynamoDBClient client = new AmazonDynamoDBClient(awsCredentials, RegionEndpoint.GetBySystemName(region));

                var request1 = new ScanRequest
                {
                    TableName = tableName
                };
                var response = await client.ScanAsync(request1);

                int id = ++response.Count;                               
                var request = new PutItemRequest
                {
                    TableName = tableName,
                    Item = new Dictionary<string, AttributeValue>()
                      {
                          { "ID", new AttributeValue { N = id.ToString() }},
                          { "ContactID", new AttributeValue { S = inputMessageData.Details.ContactData.ContactId }},
                          { "CustomerNumber", new AttributeValue { S = inputMessageData.Details.ContactData.CustomerEndpoint.Address }},
                          { "FlowType", new AttributeValue { S = inputMessageData.Details.Parameters.flowType.ToString()}},
                          { "InitialContactID", new AttributeValue { S = inputMessageData.Details.ContactData.InitialContactId}},                          
                          { "Channel", new AttributeValue { S = inputMessageData.Details.ContactData.Channel }},
                          { "InteractionDateTime", new AttributeValue { S = interactionDateTime }},
                          { "CustomerJourneyFlow", new AttributeValue { S = inputMessageData.Details.Parameters.Intent }},
                    }
                };
                await client.PutItemAsync(request);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in AddCustomerMeta : " + ex);
            }           
        }
    }
}
