﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DynamoDBConnector
{
    public class InputMessageData
    {
        public string contactID { get; set; }
        public string initialContactID { get; set; }
        public string customerNumber { get; set; }
        public string channel { get; set; }
        public string flowType { get; set; }
        public string interactionDateTime { get; set; }
        public string requestType { get; set; }
    }
}
