﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConnectCallStatisticsDashboard
{
    public class Attributes
    {
    }

    public class CustomerEndpoint
    {
        /// <summary>
        /// 
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Type { get; set; }
    }

    public class Customer
    {
        /// <summary>
        /// 
        /// </summary>
        public string Audio { get; set; }
    }

    public class MediaStreams
    {
        /// <summary>
        /// 
        /// </summary>
        public Customer Customer { get; set; }
    }

    public class References
    {
    }

    public class SystemEndpoint
    {
        /// <summary>
        /// 
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Type { get; set; }
    }

    public class ContactData
    {
        /// <summary>
        /// 
        /// </summary>
        public Attributes Attributes { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Channel { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ContactId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public CustomerEndpoint CustomerEndpoint { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string CustomerId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string InitialContactId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string InitiationMethod { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string InstanceARN { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string LanguageCode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public MediaStreams MediaStreams { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string PreviousContactId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Queue { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public References References { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public SystemEndpoint SystemEndpoint { get; set; }
    }

    public class Parameters
    {
        /// <summary>
        /// 
        /// </summary>
        public string flowType { get; set; }
        public string Intent { get; set; }
    }

    public class Details
    {
        /// <summary>
        /// 
        /// </summary>
        public ContactData ContactData { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Parameters Parameters { get; set; }
    }

    public class ContactFlowData
    {
        /// <summary>
        /// 
        /// </summary>
        public Details Details { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Name { get; set; }
    }

    public class CallStatsData
    {
        public int ID { get; set; }
        public string Channel { get; set; }
        public string ContactID { get; set; }
        public string CustomerNumber { get; set; }
        public string FlowType { get; set; }
        public string InitialContactID { get; set; }
        public string InteractionDateTime { get; set; }
        public string CustomerJourneyFlow { get; set; }
    }

    class EventData
    {
        public string eventName { get; set; }
        public string channel { get; set; }
        public string contactID { get; set; }
        public object eventInfo { get; set; }       
        public float faceComparePercentage { get; set; }
    }
}
