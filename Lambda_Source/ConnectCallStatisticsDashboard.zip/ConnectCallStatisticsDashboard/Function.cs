using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Amazon;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon.Lambda.APIGatewayEvents;
using Amazon.Lambda.Core;
using Amazon.Runtime;
using Newtonsoft.Json;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace ConnectCallStatisticsDashboard
{
    public class Function
    {

        /// <summary>
        /// A simple function that takes a string and does a ToUpper
        /// </summary>
        /// <param name="input"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        /// 
        List<CallStatsData> callStatsDataObj = new List<CallStatsData>();
        public string FunctionHandler(string input, ILambdaContext context)
        {
            return input?.ToUpper();
        }

        public async Task<string> getDataFromDB()
        {
            string region, iamUserID, iamSecretValue, tableName;
            string interactionDateTime = DateTime.Now.ToString("yyyyMMddHHmmss");

            tableName = Environment.GetEnvironmentVariable("DBTableName");
            region = Environment.GetEnvironmentVariable("Region");
            iamUserID = Environment.GetEnvironmentVariable("IAMUserID");
            iamSecretValue = Environment.GetEnvironmentVariable("IAMSecret");

            Console.WriteLine("tableName " + tableName + ", region " + region + ", iamUserID " + iamUserID + ", iamSecretValue " + iamSecretValue);
            var awsCredentials = new BasicAWSCredentials(iamUserID, iamSecretValue);

            AmazonDynamoDBClient client = new AmazonDynamoDBClient(awsCredentials, RegionEndpoint.GetBySystemName(region));

            var request1 = new ScanRequest
            {
                TableName = tableName
            };
            var response = await client.ScanAsync(request1);
            //response.
            CallStatsData data = null;
            callStatsDataObj.Clear();
            foreach (Dictionary<string, AttributeValue> resp in response.Items)
            {
                data = new CallStatsData();
                data.ID = Convert.ToInt32(resp["ID"].N);
                data.Channel = resp["Channel"].S;
                data.ContactID = resp["ContactID"].S;
                data.CustomerNumber = resp["CustomerNumber"].S;
                data.FlowType = resp["FlowType"].S;
                data.InitialContactID = resp["InitialContactID"].S;
                data.InteractionDateTime = resp["InteractionDateTime"].S;
                data.CustomerJourneyFlow = resp["CustomerJourneyFlow"].S;
                callStatsDataObj.Add(data);
            }

            EventData eventData = new EventData()
            {
                eventName = "OnGetCallStatsData",
                eventInfo = callStatsDataObj
            };
            string jsonMessage = JsonConvert.SerializeObject(eventData);
            return jsonMessage;
        }

        public APIGatewayProxyResponse GetCallStatsData(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                Console.WriteLine("GetCallStatsData : " + input);

                Task<string> data = getDataFromDB();

                var headers = new Dictionary<string, string>();
                headers.Add("Access-Control-Allow-Header", "Content-Type");
                headers.Add("Access-Control-Allow-Origin", "*");
                headers.Add("Access-Control-Allow-Methods", "OPTIONS,POST,GET");

                var result = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = data.Result,
                };

                Console.WriteLine("GetCallStatsData : Output: " + result);
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in GetCallStatsData : " + ex);
            }

            var result1 = new APIGatewayProxyResponse
            {
                StatusCode = (int)HttpStatusCode.OK,
                Body = "Failed",
                Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
            };

            return result1;
        }
    }
}
