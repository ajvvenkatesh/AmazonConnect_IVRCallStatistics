using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon;
using Amazon.Lambda.Core;
using Amazon.Pinpoint;
using Amazon.Pinpoint.Model;
using Amazon.Runtime;
using Newtonsoft.Json;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace SendSMSFromContactFlowToCaller
{
    public class Function
    {
        
        /// <summary>
        /// A simple function that takes a string and does a ToUpper
        /// </summary>
        /// <param name="input"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public string FunctionHandler(string input, ILambdaContext context)
        {
            return input?.ToUpper();
        }

        public object SendSMSFromContactFlowToCaller(ContactFlowData input, ILambdaContext context)
        {
            Console.WriteLine("SendSMSFromContactFlowToCaller : " + JsonConvert.SerializeObject(input));
            MessageData messageData = new MessageData()
            {
                message = input.Details.Parameters.message,
                number = input.Details.ContactData.CustomerEndpoint.Address
            };
            Task.Run(() => SendMessage(messageData)).Wait();
            Console.WriteLine("SendSMSFromContactFlowToCaller : Message sent!");

            string returnValue = "Success";
            var result = new
            {
                RetVal = $"\"{returnValue}\""
            };

            return result;
        }

        public async Task SendMessage(MessageData messageData)
        {
            string region, iamUserID, iamSecretValue, pinpointProjectID, messageType;
            
            string number = messageData.number;
            string message = messageData.message;

            messageType = Environment.GetEnvironmentVariable("MessageType"); //Type of message TRANSACTIONAL/PROMOTIONAL
            pinpointProjectID = Environment.GetEnvironmentVariable("PinpointProjectID");
            region = Environment.GetEnvironmentVariable("Region");
            iamUserID = Environment.GetEnvironmentVariable("IAMUserID");
            iamSecretValue = Environment.GetEnvironmentVariable("IAMSecret");

            var awsCredentials = new BasicAWSCredentials(iamUserID, iamSecretValue);
            using (AmazonPinpointClient client = new AmazonPinpointClient(awsCredentials, RegionEndpoint.GetBySystemName(region)))
            {
                SendMessagesRequest sendRequest = new SendMessagesRequest
                {
                    ApplicationId = pinpointProjectID,
                    MessageRequest = new MessageRequest
                    {
                        Addresses = new Dictionary<string, AddressConfiguration>
                        {
                            {
                                number,
                                new AddressConfiguration
                                {
                                    ChannelType = "SMS"
                                }
                            }
                        },
                        MessageConfiguration = new DirectMessageConfiguration
                        {
                            SMSMessage = new SMSMessage
                            {
                                Body = message,
                                MessageType = messageType,
                            }
                        }
                    }
                };
                SendMessagesResponse response = await client.SendMessagesAsync(sendRequest);
            }
        }
    }
}
